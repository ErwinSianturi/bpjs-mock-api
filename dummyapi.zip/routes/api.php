<?php

use App\Http\Controllers\Api\BpjsMockController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Prefix: /api/v1/mock-bpjs
|
| Note:
| - 'hospital_finder' and 'search_hospital' share the POST /hospitals endpoint.
|
*/

Route::prefix('v1/mock-bpjs')->group(function () {
    Route::post('/check-bpjs', [BpjsMockController::class, 'checkBpjs']);
    Route::post('/referral-status', [BpjsMockController::class, 'referralStatus']);
    Route::post('/hospitals', [BpjsMockController::class, 'hospitals']);
    Route::post('/specialists', [BpjsMockController::class, 'specialists']);
    Route::post('/search-web', [BpjsMockController::class, 'searchWeb']);
});
